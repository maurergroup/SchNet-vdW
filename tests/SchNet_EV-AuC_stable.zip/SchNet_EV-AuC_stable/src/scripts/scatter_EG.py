import numpy as np

qm=np.load("evaluation_qmvalues.npz")
nn=np.load("evaluation_values.npz")

shape1=qm['energy'].shape[0]
shape2=qm['energy'].shape[1]
f1=shape1
f2=shape2
print(qm['forces'].shape)
f3=qm['forces'].shape[2]



energies_nn = [] #np.zeros((int(shape1*shape2),1))
energies_qm = [] #np.zeros((int(shape1*shape2),1))
energystring_nn = ""
energystring_qm = ""
forces_nn = [] #np.zeros((int(shape1*shape2*f3*f4),1))
forces_qm = [] #forces_nn

iterator=-1
for istate in range(qm['energy'].shape[0]):
    for jstate in range(qm['energy'].shape[1]):
        energies_nn.append(nn['energy'][istate][jstate])
        energystring_nn+="%12.9f " %(nn['energy'][istate][jstate])
        energystring_qm+="%12.9f " %(qm['energy'][istate][jstate])
        energies_qm.append(qm['energy'][istate][jstate])
    energystring_nn+="\n"
    energystring_qm+="\n"
file = open("Energy_NN","w")
file.write(energystring_nn)
file.close()
file = open("Energy_QC","w")
file.write(energystring_qm)
file.close()
print(nn['forces'].shape)
energies_nn=np.array(energies_nn)
energies_qm=np.array(energies_qm)
MAE= np.abs(energies_nn-energies_qm)
print("MAE Energy [eV]", np.mean(MAE)*27.211)
MSE=np.abs(energies_nn-energies_qm)**2
print("RMSE Energy [eV]", np.sqrt(np.mean(MSE))*27.211)
for i in range(shape1):
    for j in range(shape2):
        for k in range(f3):
                forces_nn.append(nn['forces'][i][j][k])
                forces_qm.append(qm['forces'][i][j][k])
forces_nn=np.array(forces_nn)
forces_qm=np.array(forces_qm)

MAE=np.abs(forces_nn-forces_qm)
MSE=np.abs(forces_nn-forces_qm)**2
print("MAE Forces [ev/A]", np.mean(MAE)*27.211*1.8897)
print("RMSE Forces [eV/A]", np.sqrt(np.mean(MSE))*27.211*1.8897)



f3=open("forces.txt","w")
f2=open("energy.txt","w")
for i in range(energies_nn.shape[0]):
    f2.write("%12.9f %12.9f\n" %(energies_nn[i],energies_qm[i]))
f2.close()
for i in range(forces_nn.shape[0]):
    f3.write("%12.9f %12.9f \n" %(forces_nn[i],forces_qm[i]))
f3.close()
