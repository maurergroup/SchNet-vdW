import numpy as np
from ase.visualize import view
from ase.atoms import Atoms
from sys import argv
from ase.io import read, write
from ase.io.trajectory import TrajectoryWriter
from os import system
from schnetpack.data import AtomsData
def write_geoms(filename,dbname,n_number):
  #filename =  '/storage/chem/mssdjc/DB/Shay_Transform/001/aims.out'
  #filename = argv[1]
  #units: energy [eV], forces [eV/A], geometry [A]
  #PBE atomic_zora no PBC
  all_energy=[]
  all_forces=[]
  atoms_buffer=[]
  property_buffer=[]
  all_atypes=[]
  all_geoms=[]
  atypes=[]
  all_force_mask=[]
  geoms = []
  force_index=[]
  all_force_index=[]
  all_natoms=np.zeros((n_number,1))
  for filenumber in range(n_number):  
    try:
        lines = open("%03d/%s" %(int(filenumber+1),filename)).readlines()
        for l, line in enumerate(lines):
          if "The structure contains" in line:
            s=line.split()
            all_natoms[filenumber] = int(s[3]) 
    except IOError:
        print("File in folder %i not accessible" %filenumber) 
  for filenumber in range(n_number):
    try:
        lines = open("%03d/%s" %(int(filenumber+1),filename)).readlines()
        for l, line in enumerate(lines):
          if "Atomic structure:" in line:
            iatom=-1
            geoms=[]
            atypes=[]
            natoms=int(all_natoms[filenumber])
            for natom in range(natoms):
              iatom+=1
              atomline=lines[l+natom+2].split()
              atypes.append(atomline[3])
              if atomline[3]=="C":
                  geoms.append([float(atomline[4]),float(atomline[5]),float(atomline[6])])
              else:
                  force_index.append(iatom)
                  geoms.append([float(atomline[4]),float(atomline[5]),float(atomline[6])])
            all_force_index.append(force_index)
            all_atypes.append(atypes)
            all_geoms.append(np.array(geoms))
            atoms = Atoms(atypes,np.array(geoms))
            atoms_buffer.append(atoms)
            break
        for l,line in enumerate(lines):
          index = -1
          geom_index = 0
          forces=np.zeros((natoms,3))
          force_mask = np.zeros((natoms,3))
          if "Energy and forces in a compact form" in line:
            index+=1
            energy = float(lines[l+2].split()[5])
            all_energy.append(energy)
            for relevant_atoms in range(len(all_force_index[index])):
              for xyz in range(3):
                force_mask[all_force_index[index][relevant_atoms],:]=1.0 
                forces[all_force_index[index][relevant_atoms]][xyz]=lines[l+5+all_force_index[index][relevant_atoms]].split()[2+xyz]
            all_force_mask.append(force_mask)
            all_forces.append(forces)     
           #geometry of next step
          if "Updated atomic structure:" in line:
            geom_index+=1
            iatom=-1
            geoms=[]
            force_index=[]
            atypes=[]
            for natom in range(natoms):
              iatom+=1
              atomline=lines[l+natom+2].split()
              atypes.append(atomline[4])
              if atomline[4]=="C":
                  geoms.append([float(atomline[1]),float(atomline[2]),float(atomline[3])])
              else:
                  force_index.append(iatom)
                  geoms.append([float(atomline[1]),float(atomline[2]),float(atomline[3])])
            all_force_index.append(np.array(force_index))
            all_atypes.append(atypes)
            all_geoms.append(np.array(geoms))
            atoms = Atoms(atypes,np.array(geoms))
            atoms_buffer.append(atoms)
    except IOError:
        print("File in folder %i not accessible" %filenumber) 
      #print(len(all_geoms),len(all_atypes),len(all_force_index),len(all_energy),len(all_forces))
      #print(all_energy)
      #charge_buffer.append(charge)
  #get the mean of data
  mean_energy = np.mean(all_energy)
  print(mean_energy) 
  #print(np.array(all_geoms).shape)
  #print(np.array(all_forces).shape)
  #print(np.array(all_energy).shape)
  energy_scaled = np.array(all_energy)[:,] - mean_energy
  #print(energy_scaled)
  #print(energy_scaled.shape)
  #print(np.array(all_energy)[0],energy_scaled[0])
  for index in range(len(all_energy)):
    property_list = ["energy","forces"] #,"forces_index"]
    available_properties = { 'energy' : energy_scaled[index],
                    'forces'  : np.array(all_forces)[index]}
                    #'forces_index' : np.array(all_force_index)[index]}
    #Append list 
    #charge_buffer.append(charge)
    property_buffer.append(available_properties)


  #get schnet format
  spk_data = AtomsData(dbname,available_properties=property_list)
  #print(all_energy)
  spk_data.add_systems(atoms_buffer,property_buffer)
  #get metadata
  metadata={}
  metadata['mean_energy'] = mean_energy
  metadata['ref']="Reference: DFT/PBE, no PBC, Au on C"
  spk_data.set_metadata(metadata)
  return all_geoms

def write_traj(dbname):
  from ase import db
  from ase.io import write,read
  #read geometries from db file to double check if it is put into the db correctly
  #and in case one only wants to look at a db
  all_atoms=[]
  with db.connect(dbname) as conn:
    for idx in range(len(conn)):
      row=conn.get(idx+1)
      atoms=row.toatoms()
      all_atoms.append(atoms)
  #geoms=read(dbname)
  trajfile=write("traj.xyz",all_atoms,append=True)
  
def make_standardization(dbname):
    from ase import db
    all_atoms=[]
    all_data=[]
    with db.connect(dbname) as conn: 
      for idx in range(len(conn)):
        row=conn.get(idx+1)
        atoms=row.toatoms()
        all_atoms.append(atoms)
        data=row.data
        all_data.append(data)
    print(all_data)
    #print(all_atoms)
    print(all_data[0]['energy'])
    print(all_data[0]['forces'][700])
    #print(np.array2string(all_data[0]['energy'],formatter={'float_kind':lambda x: "%.6f" %x}))
if __name__ == "__main__":

    try:
        script, filename, dbname, number = argv
    except IOError:
        print("USAGE: Script.py <filename (aims.out)> <db-filename> <number of aims.out files>")

#units should be atomic units always!
#forces are -gradients!
filename = str(argv[1])
dbname = str(argv[2])
n_files = int(argv[3])
all_geoms=write_geoms(filename,dbname,n_files)
write_traj(dbname)
#cannot be done afterwards
#can be used for testing
#make_standardization(dbname)
