class Properties:
    """
    Common properties
    """
    eigenvalues_active = "eigenvalues_active"
    energy = 'energy'
    forces = 'forces'
    eigenvalues = 'eigenvalues'
    sum_occ_orb = 'sum_occ_orb'
    occ_orb = 'occ_orb'
    unocc_orb = 'unocc_orb'
    occ_orb_forces='occ_orb_forces'
    delta_E_forces = 'delta_E_forces'
    eigenvalues_forces = 'eigenvalues_forces'
    homo_lumo = 'homo_lumo'
    hirshfeld_volumes = "hirshfeld_volumes"
    delta_E = 'delta_E'
    # Only for prediction and calculator
    hessian = 'hessian'
    eigenvalues_active_forces = "eigenvalues_active_forces"

    # Available properties
    properties = [
        energy,
        forces,
        eigenvalues,
        occ_orb,
        hirshfeld_volumes,
        unocc_orb,
        homo_lumo,
        delta_E,
        eigenvalues_active
    ]

    # Properties for which normalization is meaningful
    normalize = [
        energy,
        eigenvalues,
        delta_E,
        occ_orb,
        unocc_orb,
        homo_lumo,
        sum_occ_orb,
        eigenvalues_active
    ]

    # Hessians available
    hessians_available = [
        energy
    ]

    # Standard mappings for properties
    mappings = {
        energy: (energy, 'y'),
        forces: (energy, 'dydx'),
        eigenvalues: (eigenvalues, 'y'),
        eigenvalues_forces: (eigenvalues, 'dydx'),
        occ_orb: (occ_orb, 'y'),
        occ_orb_forces: (occ_orb, 'dydx'),
        hirshfeld_volumes: (hirshfeld_volumes, "yi"),
        unocc_orb: (unocc_orb, 'y'),
        delta_E: (delta_E, 'y'),
        delta_E_forces: (delta_E_forces,'dydx'),
        homo_lumo:(homo_lumo,'y'),
        sum_occ_orb: (sum_occ_orb,'y'),
        eigenvalues_active: (eigenvalues_active, 'y'),
        eigenvalues_active_forces:(eigenvalues_active, 'dydx')
    }

    n_unocc = 'n_unocc'
    n_occ = 'n_occ'
    n_orb = 'n_orb'
