import torch
import numpy as np

import schnetpack as spk


class MeanSquaredError(spk.metrics.MeanSquaredError):

    def __init__(self, target, model_output=None, bias_correction=None,
                 name=None, element_wise=False):
        name = 'MSE_' + target if name is None else name
        super(MeanSquaredError, self).__init__(target, model_output=model_output, bias_correction=bias_correction,
                                                    name=name, element_wise=element_wise)

    def _get_diff(self, y, yp):
        diff = y - yp
        diff = (torch.abs(diff))
        if self.bias_correction is not None:
            diff += self.bias_correction
        return diff


class RootMeanSquaredError(MeanSquaredError):

    def __init__(self, target, model_output=None, bias_correction=None,
                 name=None, element_wise=False):
        name = 'RMSE_' + target if name is None else name
        super(RootMeanSquaredError, self).__init__(target, model_output,
                                                        bias_correction, name,
                                                        element_wise=element_wise)

    def aggregate(self):
        return np.sqrt(self.l2loss / self.n_entries)


class MeanAbsoluteError(spk.metrics.MeanAbsoluteError):

    def __init__(self, target, model_output=None, bias_correction=None,
                 name=None, element_wise=False):
        name = 'MAE_' + target if name is None else name
        super(MeanAbsoluteError, self).__init__(target, model_output=model_output, bias_correction=bias_correction,
                                                     name=name, element_wise=element_wise)

    def _get_diff(self, y, yp):
        diff = y - yp
        diff = (torch.abs(diff))

        if self.bias_correction is not None:
            diff += self.bias_correction
        return diff
