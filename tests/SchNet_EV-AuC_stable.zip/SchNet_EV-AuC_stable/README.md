# SchNet_EV
SchNet to model eigenvalues and related stuff

branch: Au_C_Cluster
development branch to train energy on a large data base, but restrict the force calculation to a subset. Additional argument: "--force_mask" and "--force_mask_index" to add the atoms which should be excluded from training
